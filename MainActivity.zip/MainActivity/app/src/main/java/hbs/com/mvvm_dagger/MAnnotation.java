package hbs.com.mvvm_dagger;

@interface MAnnotation {
    String value();
    String name();
}